// script.js: logic for the transfer pricing risk assessment calculator

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('risk-form');
  const resultContainer = document.getElementById('result');
  const riskLevelElem = document.getElementById('risk-level');
  const riskScoreElem = document.getElementById('risk-score');
  const recommendationsElem = document.getElementById('recommendations');

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    // Collect values and convert to numbers
    const data = new FormData(form);
    let score = 0;
    for (const [key, value] of data.entries()) {
      score += parseInt(value, 10);
    }
    // Determine risk level thresholds
    let level = '';
    let recommendations = '';
    if (score <= 4) {
      level = 'Low risk';
      recommendations = '<ul>' +
        '<li>Continue to maintain comprehensive transfer pricing documentation and ensure compliance with local regulations.</li>' +
        '<li>Monitor transactions and update functional analyses as business models evolve.</li>' +
        '<li>Conduct periodic internal reviews to ensure policies reflect actual conduct and market conditions.</li>' +
        '</ul>';
    } else if (score <= 9) {
      level = 'Moderate risk';
      recommendations = '<ul>' +
        '<li>Review the specific risk indicators flagged in this assessment (e.g., intangible transactions, payments to low‑tax jurisdictions or high leverage) and ensure they are supported by robust benchmarking and documentation.</li>' +
        '<li>Ensure the legal owners of intangible assets perform and control DEMPE functions, or adjust compensation accordingly.</li>' +
        '<li>Strengthen the quality of your transfer pricing documentation and align policies with the functional and risk profiles of each entity.</li>' +
        '<li>Consider seeking professional advice to address potential risk areas.</li>' +
        '</ul>';
    } else {
      level = 'High risk';
      recommendations = '<ul>' +
        '<li>Many high‑risk indicators are present. Engage a qualified transfer pricing advisor to perform a thorough risk assessment and develop a mitigation plan.</li>' +
        '<li>Prepare detailed functional and economic analyses (including DEMPE for intangibles) and ensure your policies reflect the commercial reality of your business.</li>' +
        '<li>Reassess transactions involving intangibles, royalty payments, and intercompany loans to ensure arm’s length pricing.</li>' +
        '<li>Ensure comprehensive documentation is prepared for each jurisdiction and address any operational or compliance issues.</li>' +
        '</ul>';
    }
    // Display the result
    riskLevelElem.innerHTML = `<strong>${level}</strong>`;
    riskScoreElem.innerHTML = `Your risk score is <strong>${score}</strong>.`;
    recommendationsElem.innerHTML = `<h3>Recommendations</h3>${recommendations}`;
    resultContainer.classList.remove('hidden');
    // Scroll to result
    resultContainer.scrollIntoView({ behavior: 'smooth' });
  });
});