# Transfer Pricing Risk Assessment Calculator

This simple web application allows taxpayers, finance teams and transfer pricing specialists to estimate the potential **transfer pricing risk** associated with their intercompany transactions. By answering a series of practical questions, the tool generates a numerical risk score and categorises the result as **low**, **moderate** or **high** risk. It also provides recommendations to help users understand how to mitigate the flagged risks.

## Key Features

* **Practical questions** – The questionnaire addresses common risk indicators identified by tax authorities and professional guidance, such as large transactions, transactions involving intangibles, payments to low‑tax jurisdictions and quality of documentation.
* **Simple scoring model** – Each answer contributes to an overall risk score. The result is displayed along with tailored recommendations.
* **Client‑side only** – The calculator is a static web page built with HTML, CSS and vanilla JavaScript. It does not require any server‑side processing.

## Running the Calculator

1. **Deploy on Glitch**: Log into your [Glitch](https://glitch.com) account and create a new project. You can import these files by clicking **New Project → Import from GitHub**, then entering the URL of your repository, or manually uploading the files via the Glitch editor.
2. **Files required**:
   - `index.html` – main page with the questionnaire
   - `styles.css` – stylesheet for basic styling
   - `script.js` – JavaScript logic for scoring and displaying results
   - `README.md` – this guide (optional for deployment)
3. **View the app**: Once the files are uploaded, Glitch will automatically serve `index.html` at the root of your project. Open the project’s live view to start using the calculator.

## How It Works

* Each question corresponds to a risk factor identified in the **OECD Draft Handbook on Transfer Pricing Risk Assessment** and other authoritative sources.
* Answers are assigned a numerical weight based on the relative importance of the risk indicator (e.g., transactions involving intangible assets or payments to low‑tax jurisdictions have higher weights).
* The total score determines the risk category:

  | Score Range | Risk Category | Interpretation |
  |------------|--------------|----------------|
  | 0–4        | Low          | Few or no high‑risk indicators; maintain good documentation and compliance. |
  | 5–9        | Moderate     | Some risk indicators present; review policies and improve documentation. |
  | 10+        | High         | Multiple high‑risk indicators; consult a transfer pricing advisor. |

## References

The risk indicators used in this calculator are informed by internationally recognised guidance:

* **Transfer Pricing Risk Factors** – Large transactions, intangible assets, taxpayer attributes and jurisdictional factors impact risk【301408221499028†L451-L465】.
* **OECD Draft Handbook on Transfer Pricing Risk Assessment** – Highlights specific risk indicators such as transactions in low‑tax jurisdictions, royalty or management fee payments to low‑tax affiliates, intra‑group service transactions, excessive debt, transfer of intangibles and business restructurings【514820013077104†L90-L139】.
* **Operational risks** – Cross‑border payments may involve FX exposure, payment delays, hidden charges and compliance lapses【309336096237037†L161-L172】.
* **Functional and risk analyses** – Misalignments between functions, assets and risks can raise red flags【309336096237037†L129-L139】.

This tool provides an indicative assessment only and should not be relied upon as professional advice. For comprehensive transfer pricing analysis and compliance, users should consult qualified tax advisors.